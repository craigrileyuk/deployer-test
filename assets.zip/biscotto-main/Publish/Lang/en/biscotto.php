<?php

return [
    'necessary'          => 'Necessary',
    'functional'         => 'Functional',
    'statstics'          => 'Statstics',
    'marketing'          => 'Marketing',
    'preference_message' => 'Customize your preference',
    'policy'             => 'Cookie policy',
    'save'               => 'Save and Submit',
    'customize'          => 'Customize',
    'allow_all'          => 'Allow All',
    'allow_cookie'       => 'Do you allow us to use cookies?',
    'cookie_message'     => 'Your Cookie message',
];
